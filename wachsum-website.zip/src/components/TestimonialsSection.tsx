"use client";

import { Card, CardContent } from "@/components/ui/card";

export default function TestimonialsSection() {
  const testimonials = [
    {
      quote: "We already have 24/7 chat support for our product, Socialmonials. However, we had just invested in all new tutorial videos and knowledgebase articles for our white label clients to support their resale customers.",
      author: "Craig",
      role: "CEO",
      avatar: "👨‍💼",
      company: "S"
    },
    {
      quote: "It's one of the better solutions for chatbots and it executes tactically. The UI/UX is simple to use and it's an extremely small learning curve with some areas of the software, but that's where Wachsum support comes in.",
      author: "resource53",
      role: "User",
      avatar: "👤",
      company: ""
    },
    {
      quote: "The team at wachsum.app proved to be incredibly helpful as we tailored the chatbot to accommodate our German operations. Despite our limited technical knowledge as content marketers, we successfully went live the following day with the customized chatbot.",
      author: "Gerhardt",
      role: "Marketing Manager",
      avatar: "👨‍💻",
      company: "G"
    }
  ];

  return (
    <section className="py-16 lg:py-24 bg-gray-900 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <p className="text-blue-400 font-medium mb-2">Testimonials</p>
          <h2 className="text-3xl lg:text-5xl font-bold mb-6">
            Why Customers Love Us
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-gray-800 border-gray-700 text-white">
              <CardContent className="p-6">
                <div className="mb-4">
                  <svg className="w-8 h-8 text-blue-400 mb-4" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M6.5 2.5C6.5 1.11929 7.61929 0 9 0C10.3807 0 11.5 1.11929 11.5 2.5V7.5C11.5 8.88071 10.3807 10 9 10C7.61929 10 6.5 8.88071 6.5 7.5V2.5Z"/>
                    <path d="M13.5 2.5C13.5 1.11929 14.6193 0 16 0C17.3807 0 18.5 1.11929 18.5 2.5V7.5C18.5 8.88071 17.3807 10 16 10C14.6193 10 13.5 8.88071 13.5 7.5V2.5Z"/>
                  </svg>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    {testimonial.quote}
                  </p>
                </div>

                <div className="flex items-center">
                  <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold mr-3">
                    {testimonial.company || testimonial.avatar}
                  </div>
                  <div>
                    <p className="font-semibold">{testimonial.author}</p>
                    <p className="text-gray-400 text-sm">{testimonial.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Navigation dots */}
        <div className="flex justify-center space-x-2">
          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
          <div className="w-2 h-2 bg-gray-600 rounded-full"></div>
          <div className="w-2 h-2 bg-gray-600 rounded-full"></div>
        </div>
      </div>
    </section>
  );
}
