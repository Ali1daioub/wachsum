"use client";

import { Button } from "@/components/ui/button";

export default function IntegrationsSection() {
  const integrations = [
    { name: "Freshdesk", logo: "🟢", color: "bg-green-100" },
    { name: "GoHighLevel", logo: "📊", color: "bg-yellow-100" },
    { name: "Messenger", logo: "💬", color: "bg-blue-100" },
    { name: "MadMed", logo: "🔵", color: "bg-blue-100" },
    { name: "MadMed", logo: "🔵", color: "bg-blue-100" },
    { name: "Messenger", logo: "💬", color: "bg-blue-100" },
    { name: "GoHighLevel", logo: "📊", color: "bg-yellow-100" },
    { name: "Freshdesk", logo: "🟢", color: "bg-green-100" },
    { name: "Freshdesk", logo: "🟢", color: "bg-green-100" },
    { name: "GoHighLevel", logo: "📊", color: "bg-yellow-100" },
    { name: "Messenger", logo: "💬", color: "bg-blue-100" },
    { name: "MadMed", logo: "🔵", color: "bg-blue-100" }
  ];

  return (
    <section className="py-16 lg:py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <p className="text-blue-600 font-medium mb-2">Integrations</p>
          <h2 className="text-3xl lg:text-5xl font-bold text-gray-900 mb-6">
            Unlimited Power with Complete Customization
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Easily integrate Wachsum AI into your workflow—CRMs, messaging, scheduling, and
            support tools. Our open architecture ensures seamless compatibility, flexibility, and
            scalability.
          </p>
        </div>

        {/* Integrations Grid */}
        <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6 mb-12">
          {integrations.map((integration, index) => (
            <div
              key={index}
              className={`${integration.color} rounded-lg p-4 flex flex-col items-center justify-center text-center h-20 hover:shadow-lg transition-shadow`}
            >
              <span className="text-2xl mb-1">{integration.logo}</span>
              <span className="text-xs font-medium text-gray-700">{integration.name}</span>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3">
            Explore all integrations →
          </Button>
        </div>
      </div>
    </section>
  );
}
